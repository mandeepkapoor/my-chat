package com.mindlinksoft.recruitment.mychat;

import java.util.ArrayList;
import java.util.List;

public class report {

	
	public Conversation activity(Conversation conversation) {
        List<reportModal> activityList = new ArrayList<reportModal>();
        List<Message> messagesList = new ArrayList<Message>(conversation.messages);
		
        for(Message messages : messagesList) {
         boolean reportt = true;
            for(reportModal activity : activityList) {
              if(activity.sender.equals(messages.senderId)){
            	  reportt = false;
            	  activity.messagesCount++;
              }
            }
            if(reportt) {
            	activityList.add(new reportModal(messages.senderId, 1));
            }
        }
        conversation.reports = srotDescending(activityList);
		return conversation;
		
	}
	
	public List<reportModal> srotDescending(List<reportModal> activity) {
		for (int i = 1; i < activity.size(); i++) 
        {  
            reportModal report = activity.get(i);  
            int j = i - 1;  
  
            while (j >= 0 && activity.get(j).messagesCount < report.messagesCount) 
            {  
            	activity.set(j + 1, activity.get(j));  
                j = j - 1;  
            }  
            activity.set(j + 1, report);  
        }
		
		return activity;
	}
}
