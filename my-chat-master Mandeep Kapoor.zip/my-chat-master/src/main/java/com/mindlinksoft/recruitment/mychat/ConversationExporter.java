package com.mindlinksoft.recruitment.mychat;

import com.google.gson.*;

import picocli.CommandLine;
import picocli.CommandLine.ParameterException;
import picocli.CommandLine.ParseResult;
import picocli.CommandLine.UnmatchedArgumentException;

import java.io.*;
import java.lang.reflect.Type;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a conversation exporter that can read a conversation and write it
 * out in JSON.
 */
public class ConversationExporter {

	/**
	 * The application entry point.
	 * 
	 * @param args The command line arguments.
	 * @throws Exception Thrown when something bad happens.
	 */
	public static void main(String[] args) throws Exception {
		// We use picocli to parse the command line - see https://picocli.info/

		ConversationExporterConfiguration configuration = new ConversationExporterConfiguration();
		CommandLine cmd = new CommandLine(configuration);

		try {
			ParseResult parseResult = cmd.parseArgs(args);
			// This if statement shows the output when the input is -h
			if (parseResult.isUsageHelpRequested()) {
				cmd.usage(cmd.getOut());
				System.exit(cmd.getCommandSpec().exitCodeOnUsageHelp());
				return;
			}

			// This if statement shows the output when the input is -V
			if (parseResult.isVersionHelpRequested()) {
				cmd.printVersionHelp(cmd.getOut());
				System.exit(cmd.getCommandSpec().exitCodeOnVersionHelp());
				return;
			}

			ConversationExporter exporter = new ConversationExporter();

			exporter.exportConversation(configuration.inputFilePath, configuration.outputFilePath, configuration);

			System.exit(cmd.getCommandSpec().exitCodeOnSuccess());
		} catch (ParameterException ex) {
			// This catches the error when there is problem with input or no input
			cmd.getErr().println(ex.getMessage());
			if (!UnmatchedArgumentException.printSuggestions(ex, cmd.getErr())) {
				ex.getCommandLine().usage(cmd.getErr());
			}

			System.exit(cmd.getCommandSpec().exitCodeOnInvalidInput());
		} catch (Exception ex) {
			ex.printStackTrace(cmd.getErr());
			System.exit(cmd.getCommandSpec().exitCodeOnExecutionException());
		}
	}

	/*
	 * This method is calling the read and write method and logging in console of
	 * the activity that is being carried out
	 */
	public void exportConversation(String inputFilePath, String outputFilePath,
			ConversationExporterConfiguration config) throws Exception {

		Conversation conversation = this.readConversation(inputFilePath);

		// This will generate the report if the report variable is true.
		conversation = new filteringMessages().filters(conversation, config);
		if (config.report && config.report != null) {
			conversation = new report().activity(conversation);
		}
		// After filters are applied conversation is written out in JSON Format
		this.writeConversation(conversation, outputFilePath);

		// TODO: Add more logging...
		System.out.println("Conversation exported from '" + inputFilePath + "' to '" + outputFilePath);
	}

	/*
	 * This is the method used to apply filters to the conversation within the file
	 * after the filters are applied the file is exported in json format
	 */
	public void writeConversation(Conversation conversation, String outputFilePath) throws Exception {
		// TODO: Do we need both to be resources, or will buffered writer close the
		// stream?
		try (OutputStream os = new FileOutputStream(outputFilePath, true);
				BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(os))) {

			// TODO: Maybe reuse this? Make it more testable...
			GsonBuilder gsonBuilder = new GsonBuilder();
			gsonBuilder.registerTypeAdapter(Instant.class, new InstantSerializer());

			Gson g = gsonBuilder.create();

			bw.write(g.toJson(conversation));
		} catch (FileNotFoundException e) {
			// TODO: Maybe include more information?
			throw new IllegalArgumentException("The file was not found.");
		} catch (IOException e) {
			// TODO: Should probably throw different exception to be more meaningful :/
			throw new Exception("Something went wrong");
		}
	}

	/*
	 * This is the method which reads the conversations from the text file and
	 * passed onto the write method which then applies filters.
	 */
	public Conversation readConversation(String inputFilePath) throws Exception {
		try (InputStream is = new FileInputStream(inputFilePath);
				BufferedReader r = new BufferedReader(new InputStreamReader(is))) {

			List<Message> messages = new ArrayList<Message>();

			String conversationName = r.readLine();
			String line;
			String message = "";
			while ((line = r.readLine()) != null) {
				String[] split = line.split(" ");
				// This separates the time stamp and username from all the messages, this and
				// collects messages in one place
				//it also ensures that no extra spacing is entered after the last word in the messages.
				for (int i = 0; i < split.length; i++) {
					if (i >= 2 && i < (split.length - 1)) {
						message = message + split[i] + " ";
					} else if (i >= 2 && i < split.length){
						message = message + split[i];
					}
				}
				messages.add(new Message(Instant.ofEpochSecond(Long.parseUnsignedLong(split[0])), split[1], message));
				message = "";

			}

			return new Conversation(conversationName, messages);
		} catch (FileNotFoundException e) {
			throw new IllegalArgumentException("The file was not found.");
		} catch (IOException e) {
			throw new Exception("Something went wrong");
		}
	}

	class InstantSerializer implements JsonSerializer<Instant> {
		@Override
		public JsonElement serialize(Instant instant, Type type, JsonSerializationContext jsonSerializationContext) {
			return new JsonPrimitive(instant.getEpochSecond());
		}
	}
}
