package com.mindlinksoft.recruitment.mychat;

public final class reportModal {
	//name of the sender
	public String sender;
	//Number of messages by specific sender
	public int messagesCount;
	
	public reportModal(String sender, int messagesCount) {
		 this.sender = sender;
		 this.messagesCount = messagesCount;
	 }
}
