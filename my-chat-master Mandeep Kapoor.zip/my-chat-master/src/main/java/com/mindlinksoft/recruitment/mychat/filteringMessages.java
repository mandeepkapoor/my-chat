package com.mindlinksoft.recruitment.mychat;

import java.util.ArrayList;
import java.util.List;


public class filteringMessages {

	public Conversation filters(Conversation conversation, ConversationExporterConfiguration config) throws Exception {

		if (config.userFilter != null) {
			conversation = this.filterByUser(conversation, config);
		}
		if (config.keywordFilter != null) {
			conversation = this.filterByKeyword(conversation, config);
		}

		if (config.blacklistFilter != null) {
			conversation = this.blacklistFilter(conversation, config);

		}

		return conversation;
	}

	/*
	 * This method is filtering the conversation by user name After the conversation
	 * is filtered it is returned to be compared through other criteria More filters
	 * are applied if required
	 */
	public Conversation filterByUser(Conversation conversation, ConversationExporterConfiguration config)
			throws Exception {

		List<Message> userFiltered = new ArrayList<Message>();
		for(Message messages : conversation.messages) {
			if(messages.senderId.equals(config.userFilter)) {
				userFiltered.add(messages);
			}
		}
		conversation.messages = userFiltered;
		return conversation;
	}

	/*
	 * This will filter the conversation by keyword after the user filter has been
	 * applied. if there is no user filter then all the conversation will be filter
	 * by the keywords
	 */
	public Conversation filterByKeyword(Conversation conversation, ConversationExporterConfiguration config)
			throws Exception {
		List<Message> messagesFiltered = new ArrayList<Message>();
		for(Message messages : conversation.messages) {
			if(messages.content.contains(config.keywordFilter)) {
				messagesFiltered.add(messages);
			}
		}
		conversation.messages = messagesFiltered;
		return conversation;
	}

	/*
	 * This filter replaces the blacklisted word with *redacted*
	 */
	public Conversation blacklistFilter(Conversation conversation, ConversationExporterConfiguration config)
			throws Exception {
		String[] blacklistedWords = config.blacklistFilter;
		
		for(Message messages :  conversation.messages) {
			for(String listWord : blacklistedWords) {
				String spaced[] = messages.content.split(" ");
				for (String compare : spaced) {
					if(compare.equalsIgnoreCase(listWord)) {
						messages.content = messages.content.replace(listWord, "*redacted*");
					}
				}
			}
		};
		return conversation;
	}
}
